-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.5.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for projek_pemdas2_museum
CREATE DATABASE IF NOT EXISTS `projek_pemdas2_museum` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `projek_pemdas2_museum`;

-- Dumping structure for table projek_pemdas2_museum.data_koleksi
CREATE TABLE IF NOT EXISTS `data_koleksi` (
  `no_inventaris` varchar(50) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jenis_koleksi` varchar(50) NOT NULL,
  `tgl_penemuan` varchar(50) NOT NULL,
  `surveyor` varchar(50) NOT NULL,
  `ruang_penyimpanan` varchar(50) NOT NULL,
  PRIMARY KEY (`no_inventaris`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table projek_pemdas2_museum.data_koleksi: ~5 rows (approximately)
INSERT INTO `data_koleksi` (`no_inventaris`, `nama_barang`, `jenis_koleksi`, `tgl_penemuan`, `surveyor`, `ruang_penyimpanan`) VALUES
	('K01', ' Mandau', 'Senjata', '10-01-1991', 'Agus', 'Gudang'),
	('K02', ' Parang Pacat Gantung Bini', 'Senjata', '31-10-1992', 'Nabil', 'Ruang Pameran'),
	('K03', ' Ulak-ulak', 'Budaya Tradisional', '10-01-1990', 'Nabil', 'Ruang Pameran'),
	('K04', ' Panai', 'Budaya Tradisional', '12-09-1992', 'Arbain', 'Vitrin 1'),
	('K05', ' Surat Perjanjian', 'Dokumen', '11-09-1992', 'Agus', 'Vitrin 1'),
	('K06', ' Tombak', 'Senjata', '15-04-1993', 'Arbain', 'Gudang'),
	('K08', 'Surat Hasan Basri', 'Dokumen', '12-10-2000', 'Arbain', 'Vitrin 2');

-- Dumping structure for table projek_pemdas2_museum.data_petugas
CREATE TABLE IF NOT EXISTS `data_petugas` (
  `id_petugas` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tgl_lahir` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_petugas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table projek_pemdas2_museum.data_petugas: ~3 rows (approximately)
INSERT INTO `data_petugas` (`id_petugas`, `nama`, `tgl_lahir`, `alamat`, `jabatan`) VALUES
	('P01', 'Arbain', '10-11-1998', 'Jl. B.Hasan Basri Komp. Kayu tangi 2', 'Pemandu'),
	('P02', ' Siti Mahmudah', '09-10-2000', 'JL. Kuin Selatan Gg. Seroja', 'Pemandu'),
	('P03', ' Agus', '30-10-1995', 'Jl. Pangeran Gg. Rahman', 'Pemandu');

-- Dumping structure for table projek_pemdas2_museum.jadwal_kegiatan
CREATE TABLE IF NOT EXISTS `jadwal_kegiatan` (
  `no_kegiatan` varchar(50) NOT NULL,
  `nama_kegiatan` varchar(50) NOT NULL,
  `tgl_kegiatan` varchar(50) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  PRIMARY KEY (`no_kegiatan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table projek_pemdas2_museum.jadwal_kegiatan: ~3 rows (approximately)
INSERT INTO `jadwal_kegiatan` (`no_kegiatan`, `nama_kegiatan`, `tgl_kegiatan`, `lokasi`) VALUES
	('K010923', 'Pameran Sejarah', '10-09-2023', 'Ruang Pameran'),
	('K0123', 'Pameran Lukisan', '10-12-2023', 'Ruang Koleksi'),
	('K0243', 'Pameran Senjata', '20-01-2023', 'Ruang Pameran');

-- Dumping structure for table projek_pemdas2_museum.user
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table projek_pemdas2_museum.user: ~0 rows (approximately)
INSERT INTO `user` (`username`, `password`) VALUES
	('admin1', 'wasaka123'),
	('', ''),
	('admin2', 'museum123');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
