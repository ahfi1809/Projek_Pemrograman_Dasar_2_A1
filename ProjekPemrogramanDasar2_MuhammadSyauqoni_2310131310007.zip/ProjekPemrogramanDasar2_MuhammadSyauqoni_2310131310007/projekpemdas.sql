-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Waktu pembuatan: 18 Des 2024 pada 23.51
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekpemdas`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `id_akun` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`id_akun`, `username`, `password`, `email`) VALUES
(1, 'Muhammad Syauqoni', 'admin123', 'admin123@gmail.com'),
(2, 'Isaww', 'isau123', 'Isaw31@gmail.com'),
(3, 'Akhmad', 'a1', 'a1@gmail.com'),
(4, 'saukani', 'saukani@gmail.com', 'sau'),
(5, 'saukani', 'sau123', 'sau123@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_stok` int(11) NOT NULL,
  `kondisi` varchar(50) NOT NULL,
  `tanggal_masuk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `jumlah_stok`, `kondisi`, `tanggal_masuk`) VALUES
(1, 'Proyektor', 15, 'Baik', '2024-12-12'),
(2, 'Proyektor', 5, 'Dalam Perbaikan', '2024-12-11'),
(3, 'Proyektor', 5, 'Perlu Diperbaiki', '2024-12-10'),
(5, 'HDMI', 15, 'Baik', '2024-12-16'),
(8, 'HDMI', 5, 'Dalam Perbaikan', '2024-12-16'),
(9, 'HDMI', 5, 'Perlu Diperbaiki', '2024-12-16'),
(10, 'Terminal', 25, 'Baik', '2024-12-17'),
(11, 'Terminal', 0, 'Dalam Perbaikan', '2024-12-17'),
(12, 'Terminal', 0, 'Perlu Diperbaiki', '2024-12-17');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(11) NOT NULL,
  `nama_peminjam` varchar(50) NOT NULL,
  `nim_peminjaman` int(50) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `jam_peminjaman` varchar(50) NOT NULL,
  `tanggal_peminjaman` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `jumlah_dipinjam` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `peminjaman`
--

INSERT INTO `peminjaman` (`id_peminjaman`, `nama_peminjam`, `nim_peminjaman`, `id_barang`, `jam_peminjaman`, `tanggal_peminjaman`, `status`, `jumlah_dipinjam`) VALUES
(6, 'Ahmad', 2022, 1, '14.20 - 18.00', '2024-12-13', 'Dikembalikan', 1),
(19, 'Rusli', 199210, 1, '12.10 - 14.40', '2024-12-16', 'Dikembalikan', 2),
(20, 'Rusli', 199210, 5, '12.10 - 14.40', '2024-12-16', 'Dikembalikan', 2),
(21, 'Yanto', 19920, 5, '8.50 - 12.30', '2024-12-16', 'Dikembalikan', 5),
(22, 'Rustam', 19931, 5, '7.10 - 8.50', '2024-01-01', 'Dikembalikan', 1),
(23, 'Rustam', 19931, 1, '7.10 - 8.50', '2024-01-01', 'Dikembalikan', 1),
(24, 'Udin', 2189, 5, '14.40 - 16.20', '2024-12-17', 'Dikembalikan', 5),
(25, 'Udin', 2189, 1, '14.40 - 16.20', '2024-12-17', 'Dikembalikan', 6),
(26, 'Eko', 2029, 10, '7.10 - 10.30', '2024-12-17', 'Dikembalikan', 5),
(27, 'melly', 2193, 10, '10.30 - 12.10', '2024-12-18', 'Dikembalikan', 5),
(28, 'melly', 1931, 1, '10.30 - 12.30', '2024-12-18', 'Dikembalikan', 5),
(29, 'Haerati', 1892, 10, '7.10 - 8.50', '2024-12-18', 'Dikembalikan', 5),
(30, 'Noor', 1982, 10, '7.10 - 8.50 ', '2024-12-18', 'Dikembalikan', 5),
(31, 'isaw', 2131, 10, '9.40 - 10.30', '2024-12-18', 'Dikembalikan', 5),
(32, 'isaw', 2131, 10, '7.10 - 8.50', '2024-12-18', 'Dikembalikan', 5),
(33, 'Fani', 1234, 10, '7.10 - 8.50', '2024-12-18', 'Dikembalikan', 5),
(34, 'Adit', 5679, 10, '16.20 - 18.00', '2024-12-13', 'Dikembalikan', 5),
(35, 'Adit', 5678, 5, '16.20 - 18.00', '2024-12-11', 'Dikembalikan', 5),
(36, 'Dani', 1974, 10, '8.50 - 9.40', '2024-12-18', 'Dikembalikan', 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `record`
--

CREATE TABLE `record` (
  `id_record` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_peminjaman` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `record`
--

INSERT INTO `record` (`id_record`, `id_akun`, `id_barang`, `id_peminjaman`) VALUES
(1, 1, 1, 6),
(14, 1, 1, 19),
(15, 1, 5, 20),
(16, 2, 5, 21),
(17, 3, 5, 22),
(18, 3, 1, 23),
(19, 4, 5, 24),
(20, 4, 1, 25),
(21, 1, 10, 26),
(22, 1, 10, 27),
(23, 4, 1, 28),
(24, 1, 10, 29),
(25, 1, 10, 30),
(26, 4, 10, 31),
(27, 4, 10, 32),
(28, 1, 10, 33),
(29, 1, 10, 34),
(30, 1, 5, 35),
(31, 1, 10, 36);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indeks untuk tabel `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`id_record`),
  ADD KEY `id_akun` (`id_akun`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `fk_peminjaman` (`id_peminjaman`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `akun`
--
ALTER TABLE `akun`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `record`
--
ALTER TABLE `record`
  MODIFY `id_record` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);

--
-- Ketidakleluasaan untuk tabel `record`
--
ALTER TABLE `record`
  ADD CONSTRAINT `fk_peminjaman` FOREIGN KEY (`id_peminjaman`) REFERENCES `peminjaman` (`id_peminjaman`) ON DELETE CASCADE,
  ADD CONSTRAINT `record_ibfk_1` FOREIGN KEY (`id_akun`) REFERENCES `akun` (`id_akun`),
  ADD CONSTRAINT `record_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
