/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package peminjaman_barang;

import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableColumnModel;
import javax.swing.table.DefaultTableModel;

public class RecordFrame extends javax.swing.JFrame {
    private void tampilkan_data(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Record");
        model.addColumn("ID Admin");
        model.addColumn("Admin");
        model.addColumn("NIM");
        model.addColumn("Nama ");
        model.addColumn("Waktu");
        model.addColumn("Tanggal");
        model.addColumn("Status");
        model.addColumn("Barang");
        model.addColumn("Jumlah");

        try {
            String sql = "SELECT record.id_record, record.id_akun, record.id_barang, record.id_peminjaman, akun.username, "
                        + "peminjaman.nama_peminjam, peminjaman.nim_peminjaman, peminjaman.jam_peminjaman, peminjaman.tanggal_peminjaman, "
                        + "barang.nama_barang, peminjaman.jumlah_dipinjam, peminjaman.status "
                        + "FROM record "
                        + "JOIN akun ON record.id_akun = akun.id_akun "
                        + "JOIN barang ON record.id_barang = barang.id_barang "
                        + "JOIN peminjaman ON record.id_peminjaman = peminjaman.id_peminjaman "
                        + "ORDER BY peminjaman.id_peminjaman";


            java.sql.Connection conn = (Connection) ConfigDB.config();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);

            while (res.next()) {
                model.addRow(new Object[]{
                    res.getString("id_record"), 
                    res.getString("id_akun"), 
                    res.getString("username"),
                    res.getString("nim_peminjaman"), 
                    res.getString("nama_peminjam"), 
                    res.getString("jam_peminjaman"),
                    res.getString("tanggal_peminjaman"), 
                    res.getString("status"),
                    res.getString("nama_barang"),
                    res.getString("jumlah_dipinjam")
                });
            }

            tblBarang.setModel(model);
            formatTabelPeminjaman();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private void kosongkan_data() {
        txtID.setText("(id)");
        txtNama.setText("(nama)");
        txtNim.setText("(nim)");
        txtBarang.setText("(barang)");
        txtJumlah.setText("(jumlah)");
    }
    
    private void formatTabelPeminjaman() {
    tblBarang.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); 
    TableColumnModel columnModel = tblBarang.getColumnModel(); 

    columnModel.getColumn(0).setPreferredWidth(70); // ID Record
    columnModel.getColumn(1).setPreferredWidth(70); // ID Akun
    columnModel.getColumn(2).setPreferredWidth(150); // Username
    columnModel.getColumn(3).setPreferredWidth(80); // NIM Peminjaman
    columnModel.getColumn(4).setPreferredWidth(150); // Nama Peminjam
    columnModel.getColumn(5).setPreferredWidth(100); // Jam Peminjaman
    columnModel.getColumn(6).setPreferredWidth(80); // Tanggal Peminjaman
    columnModel.getColumn(7).setPreferredWidth(100); // Status
    columnModel.getColumn(8).setPreferredWidth(70); // Nama Barang
    columnModel.getColumn(9).setPreferredWidth(70); // Jumlah Dipinjam
}
    
    public RecordFrame() {
        initComponents();
        tampilkan_data();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBarang = new javax.swing.JTable();
        txtBarang = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtJumlah = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtID = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNama = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNim = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnKembali = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        tblBarang.setBackground(new java.awt.Color(204, 204, 204));
        tblBarang.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        tblBarang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblBarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBarangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBarang);

        txtBarang.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        txtBarang.setForeground(new java.awt.Color(255, 255, 255));
        txtBarang.setText("(barang)");

        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Jumlah :");

        txtJumlah.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        txtJumlah.setForeground(new java.awt.Color(255, 255, 255));
        txtJumlah.setText("(jumlah)");

        btnUpdate.setBackground(new java.awt.Color(204, 204, 204));
        btnUpdate.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID Record :");

        txtID.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        txtID.setForeground(new java.awt.Color(255, 255, 255));
        txtID.setText("(id)");

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nama :");

        txtNama.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        txtNama.setForeground(new java.awt.Color(255, 255, 255));
        txtNama.setText("(nama)");

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("NIM :");

        txtNim.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        txtNim.setForeground(new java.awt.Color(255, 255, 255));
        txtNim.setText("(nim)");

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Barang :");

        btnKembali.setBackground(new java.awt.Color(204, 204, 204));
        btnKembali.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnKembali.setText("Kembali");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnUpdate)
                        .addGap(48, 48, 48)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtID)
                        .addGap(80, 80, 80)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txtNama)
                        .addGap(87, 87, 87)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txtNim)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtBarang)
                        .addGap(74, 74, 74)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(txtJumlah))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnKembali)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 937, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(btnKembali)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnUpdate)
                    .addComponent(jLabel1)
                    .addComponent(txtID)
                    .addComponent(jLabel4)
                    .addComponent(txtNama)
                    .addComponent(jLabel5)
                    .addComponent(txtNim)
                    .addComponent(jLabel2)
                    .addComponent(txtBarang)
                    .addComponent(jLabel6)
                    .addComponent(txtJumlah))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void tblBarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBarangMouseClicked
        int baris = tblBarang.rowAtPoint((evt.getPoint()));
               
        String id = tblBarang.getValueAt(baris,0).toString();
        txtID.setText(id);
        
        String nama = tblBarang.getValueAt(baris,4).toString();
        txtNama.setText(nama);
        
        String nim = tblBarang.getValueAt(baris,3).toString();
        txtNim.setText(nim);
        
        String barang = tblBarang.getValueAt(baris,8).toString();
        txtBarang.setText(barang);
        
        
        String jumlah = tblBarang.getValueAt(baris,9).toString();
        txtJumlah.setText(jumlah);
    }//GEN-LAST:event_tblBarangMouseClicked

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed

        int selectedRow = tblBarang.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Silakan pilih baris pada tabel terlebih dahulu.");
            return;
        }

        String idRecord = tblBarang.getValueAt(selectedRow, 0).toString(); // ID Record
        String idBarang = tblBarang.getValueAt(selectedRow, 8).toString(); // Nama Barang (ID Barang perlu disesuaikan)
        String status = tblBarang.getValueAt(selectedRow, 7).toString(); // Status
        int jumlahDipinjam = Integer.parseInt(tblBarang.getValueAt(selectedRow, 9).toString()); // Jumlah dipinjam

        if (status.equalsIgnoreCase("Dikembalikan")) {
            JOptionPane.showMessageDialog(this, "Barang sudah dikembalikan.");
            return;
        }

        try {
            java.sql.Connection conn = ConfigDB.config();

            // Update status menjadi "Dikembalikan" di tabel peminjaman
            String sqlUpdateStatus = "UPDATE peminjaman "
                                    + "SET status = 'Dikembalikan' "
                                    + "WHERE id_peminjaman = (SELECT id_peminjaman FROM record WHERE id_record = ?)";
            java.sql.PreparedStatement pstmUpdateStatus = conn.prepareStatement(sqlUpdateStatus);
            pstmUpdateStatus.setString(1, idRecord);
            int rowsUpdatedStatus = pstmUpdateStatus.executeUpdate();

            if (rowsUpdatedStatus > 0) {
                // Tambahkan kembali jumlah stok barang di tabel barang
                String sqlUpdateStok = "UPDATE barang "
                                      + "SET jumlah_stok = jumlah_stok + ? "
                                      + "WHERE nama_barang = ? AND kondisi = 'Baik'";
                java.sql.PreparedStatement pstmUpdateStok = conn.prepareStatement(sqlUpdateStok);
                pstmUpdateStok.setInt(1, jumlahDipinjam);
                pstmUpdateStok.setString(2, idBarang);
                int rowsUpdatedStok = pstmUpdateStok.executeUpdate();

                if (rowsUpdatedStok > 0) {
                    JOptionPane.showMessageDialog(this, "Status berhasil diperbarui!");
                    tampilkan_data();
                } else {
                    JOptionPane.showMessageDialog(this, "Gagal memperbarui stok barang!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Gagal memperbarui status peminjaman!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btnUpdateActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblBarang;
    private javax.swing.JLabel txtBarang;
    private javax.swing.JLabel txtID;
    private javax.swing.JLabel txtJumlah;
    private javax.swing.JLabel txtNama;
    private javax.swing.JLabel txtNim;
    // End of variables declaration//GEN-END:variables
}
